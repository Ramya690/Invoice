import React, { Component } from 'react';

class Register extends Component {
    documentData;
    constructor(props) {
        super(props);
        this.handleChange = this.handleChange.bind(this);
        this.handleFormSubmit = this.handleFormSubmit.bind(this);
        this.state = {
            firstName: '',
            lastName: '',
            email:'',
            password:'',
            confirmPassword:'',
         
        }
    }
    handleChange= (e)=> {
        this.setState({[e.target.name]:e.target.value});
    }
    // on form submit...
    handleFormSubmit(e) {
        e.preventDefault()
       localStorage.setItem('document',JSON.stringify(this.state));
    }
     
    // React Life Cycle
    componentDidMount() {
        this.documentData = JSON.parse(localStorage.getItem('document'));
     
        if (localStorage.getItem('document')) {
            this.setState({
                firstName: this.documentData.firstName,
               lastName: this.documentData.lastName,
               email: this.documentData.email,
               password: this.documentData.password,
               confirmPassword: this.documentData.confirmPassword,
        })
    } else {
        this.setState({
            firstName: '',
            lastName: '',
            email:'',
            password:'',
            confirmPassword:'',
           
        })
    }
    }
     
    render() {
        return (
          
                <div class="jumbotron">
                    <h1>Register Page</h1>
                    <form onSubmit={this.handleFormSubmit}>
          <table>
              <tr>
          <td>  <label for="firstName">FirstName:</label></td>
            <td><input type="text" name="firstName" className="form-control" value={this.state.firstName} onChange={this.handleChange} /></td>
            
            </tr>
            <tr>
           <td> <label for="lastName">LastName:</label></td>
          <td>  <input type="text"  name="lastName" className="form-control" value={this.state.lastName} onChange={this.handleChange} /></td>
            </tr>
            <tr>
           <td> <label for="email">Email:</label></td>
           <td><input type="text"  name="email" className="form-control" value={this.state.email} onChange={this.handleChange} /></td>
            </tr>
            <tr>
          <td> <label for="password">Password:</label></td>
            <td><input type="password"  name="password" className="form-control" value={this.state.password} onChange={this.handleChange} /></td>
           
            </tr>
            <tr>
          <td> <label for="confirmPassword">ConfirmPassword:</label></td>
            <td><input type="password"  name="confirmPassword" className="form-control" value={this.state.confirmPassword} onChange={this.handleChange} /></td>
            </tr>
                <a button type="button"  className="btn btn-sm btn-primary"  href="/Home">Cancel</a>
                < button type="submit"  class="btn btn-sm btn-primary" >Submit</ button></table>
                </form>
            </div>

           
            

          
            
            
        );
    }
}

export default Register;