import React, { Component } from 'react';

class WelcomePage extends Component {
    render() {
        return (
            <div class="jumbotron">
                 <h1>FirstCry</h1>
                <h4>Welcome to ShoppingCart</h4>
               
                <a button type="button"  className="btn btn-sm btn-primary" href="/Home" >Login
            </a>
                <a button type="button"  className="btn btn-sm btn-primary" href="/register" >Register
            </a>
           
            </div>
        );
    }
}

export default WelcomePage;