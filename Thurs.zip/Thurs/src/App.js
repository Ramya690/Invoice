import React from 'react';
import './App.css';
import { Route } from 'react-router-dom';

import Register from '../src/components/Register';
import Home from '../src/components/Home'
import Cart from '../src/components/Cart'

import Login from './components/Login';
function App() {
  return (
    <div className="App">
   
      
     
      <div className="container my-4">
              <Route path="/" exact component={Home} />
                <Route path="/login" exact component={Login} />
              
                <Route path="/register" exact component={Register} />
                <Route path="/cart" exact component={Cart} />
               

                </div>
     
    </div>
  );
}

export default App;
