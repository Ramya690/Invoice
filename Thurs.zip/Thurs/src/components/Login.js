import React,{ Component } from "react";

export default class Login extends Component{
     
    documentData;
    constructor(props) {
        super(props);
        this.handleChange = this.handleChange.bind(this);
        this.handleFormSubmit = this.handleFormSubmit.bind(this);

        this.state = {
            userName: '',
            password: ''
        }
    }

    handleChange= (e)=> {
        this.setState({[e.target.name]:e.target.value});
    }
    // on form submit...
    handleFormSubmit(e) {
        e.preventDefault()
       localStorage.setItem('document',JSON.stringify(this.state));
    }
     
    // React Life Cycle
    componentDidMount() {
        this.documentData = JSON.parse(localStorage.getItem('document'));
     
        if (localStorage.getItem('document')) {
            this.setState({
                userName: this.documentData.userName,
               password: this.documentData.password
        })
    }
     else {
        this.setState({
            userName: '',
            password: ''
        })
    }
    }

render()
{

    return(
    
        <div  class="jumbotron row-md-2 col-md-5 hmiddle " >
            <h1>LOGIN PAGE</h1>
 
        <form onSubmit={this.handleFormSubmit}>

        <div className="form-group">
        <label>User Name</label>
        <input type="text" name="userName" className="form-control" value={this.state.userName} 
        onChange={this.handleChange} />
        </div>

        <div className="form-group">
        <label>Password</label>
        <input type="password" name="password" className="form-control" value={this.state.password}
         onChange={this.handleChange} />
        </div>
         
        <button type="submit" className="btn btn-primary btn-block">Submit</button>
        <br/>
        <br/>
        <br/>
        <br/>

        <a class="btn btn-primary " href="/" role="button">Home</a>

        </form>
    
    
        
    
    </div>
    
    );

}

}