import React, { Component } from 'react';

class Cart extends Component {
    render() {
        return (
            <div className="container">
                <h1>Welcome To Shopping Cart</h1> 
                <div className="image">

                </div>
                
                <a class="btn btn-primary " href="/" role="button">SignOut</a>
                
                
            </div>
        );
    }
}

export default Cart;