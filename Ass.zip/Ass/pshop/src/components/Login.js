import React, { Component } from 'react';

class Login extends Component {
    render() {
        return (
            <div>
                Welcome to shoppingcart
            </div>
        );
    }
}

export default Login;