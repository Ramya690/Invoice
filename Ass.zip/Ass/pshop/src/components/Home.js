import React, { Component } from 'react';

class Login extends Component {
    
 
 
render() {
    return (
        
        <div class="jumbotron">
            <h1>Login Page</h1>
        
        
           <table>
            <tr>
           <td><label for="user">Username:</label></td>
           <td> <input type="text" id="username" class="form-control" placeholder=" " aria-describedby="loginHelp"/></td> 
            </tr>
            <tr>
           <td><label for="password">Password:</label></td>
            <td><input type="text" id="password" class="form-control" placeholder=" " aria-describedby="passwordHelp"/></td></tr>
          
            <a button type="button"  className="btn btn-sm btn-primary" href="/Login"  >Login 
            </a>
            <a button type="button"  className="btn btn-sm btn-primary" href="/register" >Register
            </a>
           
          
            </table>
            </div>
                   
    )
}
}


export default Login;