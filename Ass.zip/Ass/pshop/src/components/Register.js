import React, { Component } from 'react'; 
const emailRegex = RegExp(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i);

const formvalid= ({forErrors,...rest})=> {
  let valid = true;
// validate form errors being empty
  Object.values(forErrors).forEach((val)=>{
    val.length> 0 && (valid=false)
  });
// validate the form was filled out
  Object.values(rest).forEach(val=>{
    val=== null && (valid=false);
  });
  return valid;
};


class Register extends Component {
    documentData;
    firstNameRef = React.createRef();
    lastNameRef = React.createRef();
    emailRef = React.createRef();
    passwordRef = React.createRef();
    confirmPasswordRef = React.createRef();
    constructor(props) {
        super(props);
        this.handleChange = this.handleChange.bind(this);
        this.handleFormSubmit = this.handleFormSubmit.bind(this);
        this.state = {
            
            values:{
            firstName: '',
            lastName: '',
            email:'',
            password:'',
            confirmPassword:'',
         
        },
        errors:{
            firstName:[],
            lastName:[],
            email:[],
            password:[],
            confirmPassword:[]
        },
        wasValidate:false
    };
    
    
}


validate = () => {
    const errors = {
        firstName: [],
        lastName: [],
        email :[],
        password :[],
        confirmPassword:[]
       
    };
    if( this.firstNameRef.current.value=== '' ) {
        errors.firstName.push( 'Your name is required' );
    }
    if( this.lastNameRef.current.value=== '' ) {
        errors.lastName.push( 'Your last name is required' );
    }
    if( this.emailRef.current.value === '' ) {
        errors.email.push( 'Provide your email' );
    }
    if( this.passwordRef.current.value=== '' ) {
        errors.password.push( 'Provide your email' );
    }
    if( this.confirmPasswordRef.current.value=== '' ) {
        errors.confirmPassword.push( 'Provide your email' );
    }
    this.setState({
        ...this.state,
        errors: errors,
        wasValidated: true
    });
}

isValid = () => {
    const { firstName, lastName ,email,password,confirmPassword} = this.state.errors;
    
    return firstName.length === 0 && lastName.length === 0 && email.length === 0 && password.length===0 &&confirmPassword===0 ;
}


    handleChange= (e)=> {
        this.setState({[e.target.name]:e.target.value});
    }
    // on form submit...
    handleFormSubmit(e) {
        e.preventDefault()
       localStorage.setItem('document',JSON.stringify(this.state));
    }
     
    // React Life Cycle
    componentDidMount() {
        this.documentData = JSON.parse(localStorage.getItem('document'));
     
        if (localStorage.getItem('document')) {
            this.setState({
                firstName: this.documentData.firstName,
               lastName: this.documentData.lastName,
               email: this.documentData.email,
               password: this.documentData.password,
               confirmPassword: this.documentData.confirmPassword,
        })
    } else {
        this.setState({
            firstName: '',
            lastName: '',
            email:'',
            password:'',
            confirmPassword:'',
           
        })
    }
    }
     
    render() {
        return (
          
                <div class="jumbotron">
                    <h1>Register Page</h1>
                    <form onSubmit={this.handleFormSubmit}>
          <table>
              <tr>
          <td>  <label for="firstName">FirstName:</label></td>
            <td><input type="text" id="firstName" name="firstName"  class={`form-control ${this.state.errors.firstName.length === 0 ? `is-valid` : `is-invalid`}`} value={this.firstName} placeholder="" aria-describedby="firstNameHelp" ref={this.firstNameRef} onChange={this.handleChange} /></td>
            <div className="invalid-feedback">
                            {this.state.errors.firstName.map( error => <div>{error}</div>)}
                        </div>
            </tr>
            <tr>
           <td> <label for="lastName">LastName:</label></td>
          <td>  <input type="text" id="lastName" name="lastName" value={this.lastName} class={`form-control ${this.state.errors.lastName.length === 0 ? `is-valid` : `is-invalid`}`} placeholder="" aria-describedby="reviewerHelp" ref={this.lastNameRef} onChange={this.handleChange}  /></td>
          <div className="invalid-feedback">
                            {this.state.errors.lastName.map( error => <div>{error}</div>)}
                        </div>
            </tr>
            <tr>
           <td> <label for="email">Email:</label></td>
           <td><input type="text"  name="email" value={this.email} class={`form-control ${this.state.errors.email.length === 0 ? `is-valid` : `is-invalid`}`} placeholder="" aria-describedby="emailHelp" ref={this.emailRef} onChange={this.handleChange} /></td>
           <div className="invalid-feedback">
                            {this.state.errors.email.map( error => <div>{error}</div>)}
                        </div>
            </tr>
            <tr>
          <td> <label for="password">Password:</label></td>
            <td><input type="password"  name="password"  value={this.password} class={`form-control ${this.state.errors.password.length === 0 ? `is-valid` : `is-invalid`}`} placeholder="" aria-describedby="passwordHelp" ref={this.passwordRef} onChange={this.handleChange} /></td>
            <div className="invalid-feedback">
                            {this.state.errors.password.map( error => <div>{error}</div>)}
                        </div>
            </tr>
            <tr>
          <td> <label for="confirmPassword">ConfirmPassword:</label></td>
            <td><input type="password"  name="confirmPassword"  value={this.confirmPassword} class={`form-control ${this.state.errors.confirmPassword.length === 0 ? `is-valid` : `is-invalid`}`} placeholder="" aria-describedby="confirmPasswordHelp" ref={this.confirmPasswordRef} onChange={this.handleChange}/></td>
            <div className="invalid-feedback">
                            {this.state.errors.confirmPassword.map( error => <div>{error}</div>)}
                        </div>
            </tr>
                <a button type="button"  className="btn btn-sm btn-primary"  href="/Home">Cancel</a>
                < button type="submit"  class="btn btn-sm btn-primary" >Submit</ button></table>
                </form>
            </div>

           
            

          
            
            
        );
    }
}


export default Register;