import React from 'react';
import './App.css';
import { Route } from 'react-router-dom';
import Navbar from '../src/components/Navbar';
import Register from '../src/components/Register';
import Home from '../src/components/Home'

import WelcomePage from '../src/components/WelcomePage';
function App() {
  return (
    <div className="App">
      <Navbar/>
      
     
      <div className="container my-4">
              <Route path="/welcome" exact component={WelcomePage} />
                <Route path="/Home" exact component={Home} />
              
                <Route path="/register" exact component={Register} />
               

                </div>
     
    </div>
  );
}

export default App;
